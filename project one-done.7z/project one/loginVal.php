<?php
$user_email = $_REQUEST["email"]; $def_email = "example@ex.com";
$user_pass = $_REQUEST["pass"];   $def_pass = "pass123";

if ($user_email == $def_email && $user_pass == $def_pass  ) {
    echo "<h2 class='logokh2'/>Success<br/></h2>";
    echo "<a class='lognoa' href='index.php'/>Home</a>";
}
else {
    echo "<h2 class='lognoh2'/>please enter a correct email and password<br/></h2>";
    echo "<a class='lognoa' href='join.html'/>Go back</a>";

}


?>
<html>
       <head>
             <link rel="stylesheet" href="./assets/css/style.css">

        </head>
        </html>